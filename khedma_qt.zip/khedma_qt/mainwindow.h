#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include "service.h"
#include <QFileDialog>
#include <QDialog>
#include <QDateEdit>
#include "smtp.h"

class Connection
{
public:
    QSqlDatabase db;
public:
    Connection();
    bool createconnection();
    void closeconnection();
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
   explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:




    void on_buttonBox_modifierservice_accepted();

    void on_ajout_accepted();

    void on_tableView_res_doubleClicked(const QModelIndex &index);

    void on_boutonsupp_clicked();

    void on_buttonBox_rechercher_accepted();

    void on_lineEdit_cursorPositionChanged(int arg1, int arg2);

    void on_lineEdit_returnPressed();

    void on_pushButton_clicked();

    void on_comboBox_currentTextChanged(const QString &arg1);

    void on_buttonBox_supprimerS_accepted();

    void on_lineEdit_textChanged(const QString &arg1);

    void on_dateEdit_userDateChanged(const QDate &date);

    void on_le_id_cursorPositionChanged(int arg1, int arg2);

    void on_envoyer_clicked();

    void on_lineEdit_2_cursorPositionChanged(int arg1, int arg2);

    void on_lineEdit_2_textEdited(const QString &arg1);

    void on_lineEdit_2_textChanged(const QString &arg1);
    void sendMail();
    void mailSent(QString) ;

    void on_histoservice_cursorPositionChanged(int arg1, int arg2);

    void on_lineEdit_recherche_cursorPositionChanged(int arg1, int arg2);

    void on_lineEdit_recherche_returnPressed();

    void on_Tri_currentTextChanged(const QString &arg1);

    void on_tableView_res_activated(const QModelIndex &index);

private:
    Ui::MainWindow *ui;
    Service Serv;

};
#endif // MAINWINDOW_H
