#include "service.h"
#include <QProcess>


Service::Service()
{

    idservice =0;
    nomservice ="";
    typeservice ="";
    emplacementservice = "";
    prixservice = 0.00;
    descriptionservice="";

}


Service::Service(int id_service,QString nom_service,QString type_service,QString emplacement_service,float prix_service,QString description_service,QDate date_service)
{
    this->idservice =id_service;
    this->nomservice = nom_service;
    this->typeservice =type_service;
    this->emplacementservice = emplacement_service;
   this->prixservice = prix_service;
    this->descriptionservice=description_service;
    this->dateservice=date_service;
}

bool Service::ajouterres()
{
    QSqlQuery query;
    QString id_service=QString::number(idservice);
    QString prix_service=QString::number(prixservice);



                     query.prepare("insert into services (IDSERVICE, NOMSERVICE,TYPESERVICE, EMPLACEMENTSERVICE, PRIXSERVICE, DESCRIPTIONSERVICE, DATESERVICE )"
                                   "values(:IDSERVICE, :NOMSERVICE, :TYPESERVICE, :EMPLACEMENTSERVICE, :PRIXSERVICE,:DESCRIPTIONSERVICE, :DATESERVICE)");

                     query.bindValue(":IDSERVICE", id_service);
                     query.bindValue(":NOMSERVICE", nomservice);
                     query.bindValue(":TYPESERVICE", typeservice);
                     query.bindValue(":EMPLACEMENTSERVICE", emplacementservice);
                     query.bindValue(":PRIXSERVICE", prix_service);
                      query.bindValue(":DESCRIPTIONSERVICE", descriptionservice);
                      query.bindValue(":DATESERVICE", dateservice);
                      return query.exec();

}

QSqlQueryModel * Service::afficher_serv()
{
    QSqlQueryModel * model=new QSqlQueryModel();

    model->setQuery("select * from services");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("DATESERVICE"));


    return model;


}



bool Service::modifier_serv(int idservice, QString nomservice, QString typeservice, QString emplacementservice, float prixservice, QString descriptionservice, QDate dateservice)

{QProcess process;
    process.start("python C:/Users/nassi/OneDrive/Desktop/Projet_QT/khedma_qt/khedma_qt/message.py ");
    process.waitForFinished();


     QSqlQuery query;
//query.prepare("update services SET NOMSERVICE=:nom, TYPESERVICE=:type, EMPLACEMENTSERVICE=:emplacement  ,PRIXSERVICE=:prix, DESCRIPTIONSERVICE=:desc  WHERE IDSERVICE=:id");
query.prepare("update services SET NOMSERVICE=:nom, TYPESERVICE=:type, EMPLACEMENTSERVICE=:emplacement  ,PRIXSERVICE=50.2, DESCRIPTIONSERVICE=:desc  WHERE IDSERVICE=:id");

    //c un modele preparer pour lexecution
    query.bindValue(":id", idservice);
    query.bindValue(":nom", nomservice);
    query.bindValue(":type",typeservice);
    query.bindValue(":emplacement",emplacementservice);
    query.bindValue(":prix",prixservice);
     query.bindValue(":desc",descriptionservice);

     return    query.exec();


}


bool Service::supprimer_serv(int idservice)
{QProcess process;
    process.start("python C:/Users/nassi/OneDrive/Desktop/Projet_QT/khedma_qt/khedma_qt/message.py ");
    process.waitForFinished();

    QSqlQuery query;
    query.prepare("Delete from services where IDSERVICE= :IDSERVICE");
    query.bindValue(":IDSERVICE",idservice);
    return query.exec();
}
QSqlQueryModel * Service::chercher_serv(QString id_service)
{
QSqlQueryModel * model = new QSqlQueryModel();
QSqlQuery query;
query.prepare("select * from services WHERE id_service = :id_service");
query.bindValue(":id_service",id_service);
query.exec();
model ->setQuery(query);
model->setHeaderData(0,Qt::Horizontal,QObject::tr("Id service"));
model->setHeaderData(1,Qt::Horizontal,QObject::tr("Nom service"));
model->setHeaderData(2,Qt::Horizontal,QObject::tr("Type service"));
model->setHeaderData(3,Qt::Horizontal,QObject::tr("Emplacement service"));
model->setHeaderData(4,Qt::Horizontal,QObject::tr("Prix service"));
model->setHeaderData(5,Qt::Horizontal,QObject::tr("Description service"));

return model;
}

QSqlQueryModel * Service::recuperer(int idservice)
  {
     QSqlQueryModel * model = new QSqlQueryModel();
     QString idS = QString::number(idservice);
     model->setQuery("SELECT * FROM services WHERE IDSERVICE="+idS );
     model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
     model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
     model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
     model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
     model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
     model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));

     return model;
}

     QSqlQueryModel * Service::rechercher_service(const QString &b)
     {
        QSqlQueryModel * model = new QSqlQueryModel();
        model->setQuery("SELECT * FROM services WHERE (IDSERVICE || NOMSERVICE || TYPESERVICE || EMPLACEMENTSERVICE || PRIXSERVICE || DESCRIPTIONSERVICE) LIKE '%"+b+"%'");
        model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
        model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
        model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
        model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
        model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
        model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));
        return model;
     }


    QSqlQueryModel * Service::trier_serviceType()
    {
        QSqlQueryModel * model=new QSqlQueryModel();
        model->setQuery("SELECT * FROM services ORDER BY TYPESERVICE");
        model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
        model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
        model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
        model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
        model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
        model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));
        return model;
    }

    QSqlQueryModel * Service::trier_serviceNom()
    {
        QSqlQueryModel * model=new QSqlQueryModel();
        model->setQuery("SELECT * FROM services ORDER BY NOMSERVICE");
        model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
        model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
        model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
        model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
        model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
        model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));
        return model;
    }

    QSqlQueryModel * Service::trier_serviceId()
    {
        QSqlQueryModel * model=new QSqlQueryModel();
        model->setQuery("SELECT * FROM services ORDER BY IDSERVICE desc");
        model->setHeaderData(0,Qt::Horizontal,QObject::tr("IDSERVICE"));
        model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOMSERVICE"));
        model->setHeaderData(2,Qt::Horizontal,QObject::tr("TYPESERVICE"));
        model->setHeaderData(3,Qt::Horizontal,QObject::tr("EMPLACEMENTSERVICE"));
        model->setHeaderData(4,Qt::Horizontal,QObject::tr("PRIXSERVICE"));
        model->setHeaderData(5,Qt::Horizontal,QObject::tr("DESCRIPTIONSERVICE"));
        return model;
    }







