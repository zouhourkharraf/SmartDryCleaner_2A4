#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "service.h"

#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlRecord>
#include <QStandardItem>
#include "smtp.h"
#include <QDebug>
#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/QPrintDialog>
#include <QtPrintSupport/QtPrintSupport>


Connection::Connection(){}

bool Connection::createconnection()
{
    bool test=false;
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("source_projet2A");//inserer le nom de la source de données ODBC
    db.setUserName("system");//inserer nom de l'utilisateur
    db.setPassword("12345678");//inserer mot de passe de cet utilisateur

    if (db.open())
    test=true;
    return  test;
}

void Connection::closeconnection(){db.close();}

MainWindow::MainWindow(QWidget *parent):
     QMainWindow(parent),
     ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableView_res->setModel(Serv.afficher_serv());

}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_buttonBox_modifierservice_accepted()
{

    int id_s = ui->lineEdit_idservice_2->text().toInt();
    QString nom_s = ui->lineEdit_nomservice_2->text();
    QString emplacement_s = ui->lineEdit_emplacementservice_2->text();
   float prix_s = ui->lineEdit_prixservice_2->text().toFloat();
    QString type_s = ui->lineEdit_typeservice_2->text();
    QString description_s = ui->lineEdit_descriptionservice_2->text();
    QDate date_s = ui->dateEdit_2->date();



    Service C(id_s,nom_s,type_s,emplacement_s,prix_s,description_s,date_s);
     bool test=C.modifier_serv(id_s,nom_s,type_s,emplacement_s,prix_s,description_s,date_s);
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("Modifier une Servicet !"),
                                 QObject::tr(" Service modifiée ! \n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tableView_res->setModel(Serv.afficher_serv());
        ui->lineEdit_idservice_2->clear();
        ui->lineEdit_nomservice_2->clear();
        ui->lineEdit_typeservice_2->clear();
        ui->lineEdit_emplacementservice_2->clear();
        ui->lineEdit_prixservice_2->clear();
        ui->lineEdit_descriptionservice_2->clear();
    }

    else {

        QMessageBox::critical(nullptr, QObject::tr("Modifier Service"),
                              QObject::tr("Erreur !.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
    }
}


void MainWindow::on_ajout_accepted()
{
    QProcess process;
        process.start("python C:/Users/nassi/OneDrive/Desktop/Projet_QT/khedma_qt/khedma_qt/message.py ");
        process.waitForFinished();
    int idservice = ui->le_id->text().toInt();
    QString nomservice = ui->lineEdit_nomservice->text();
    QString typeservice = ui->lineEdit_typeservice->text();
    QString emplacementservice = ui->lineEdit_emplacementservice->text();
   float prixservice = ui->lineEdit_prixservice->text().toFloat();
    QString descriptionservice = ui->lineEdit_descriptionservice->text();
    QDate dateservice = ui->dateEdit->date();



    Service C(idservice,nomservice,typeservice,emplacementservice,prixservice,descriptionservice,dateservice);
    bool test = C.ajouterres();
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("OK"),
                                 QObject::tr("Ajout effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tableView_res->setModel(C.afficher_serv());
        ui->le_id->clear();
        ui->lineEdit_nomservice->clear();
        ui->lineEdit_typeservice->clear();
        ui->lineEdit_emplacementservice->clear();
        ui->lineEdit_prixservice->clear();
        ui->lineEdit_descriptionservice->clear();




    }else{
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                 QObject::tr("Ajout non effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel); }
}



void MainWindow::on_tableView_res_doubleClicked(const QModelIndex &index)
{


        //get and load the data
       int ids = index.data().toInt();
        Service C ;
        QSqlQueryModel* sqlQueryModel = C.recuperer(ids);
           QString id_s = sqlQueryModel->record(0).value("IDSERVICE").toString();
            QString nom_s = sqlQueryModel->record(0).value("NOMSERVICE").toString();
            QString type_s = sqlQueryModel->record(0).value("TYPESERVICE").toString();
            QString emplacement_s = sqlQueryModel->record(0).value("EMPLACEMENTSERVICE").toString();
            QString prix_s = sqlQueryModel->record(0).value("PRIXSERVICE").toString();
            QString description_s = sqlQueryModel->record(0).value("DESCRIPTIONSERVICE").toString();


    ui->lineEdit_idservice_2->setText(id_s);
    ui->lineEdit_nomservice_2->setText(nom_s);
    ui->lineEdit_typeservice_2->setText(type_s);
    ui->lineEdit_emplacementservice_2->setText(emplacement_s);
    ui->lineEdit_prixservice_2->setText(prix_s);
    ui->lineEdit_descriptionservice_2->setText(description_s);


     ui->tabWidget_2->setCurrentIndex(2);


}

void MainWindow::on_boutonsupp_clicked()
{

            Service c1;
            c1.setid_service(ui->lineEdit_idservice_2->text().toUInt());
            bool test=c1.supprimer_serv(c1.getid_service());
            if(test)
            {
                QMessageBox::information(nullptr, QObject::tr("OK"),
                                         QObject::tr("Suppression effectuer\n"
                                                     "Click Cancel to exit."), QMessageBox::Cancel);
                ui->tableView_res->setModel(c1.afficher_serv());
                ui->lineEdit_idservice_2->clear();
                ui->lineEdit_nomservice_2->clear();
                ui->lineEdit_typeservice_2->clear();
                ui->lineEdit_emplacementservice_2->clear();
                ui->lineEdit_prixservice_2->clear();
                ui->lineEdit_descriptionservice_2->clear();
            }else{
                QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                         QObject::tr("Suppresion non effectuer\n"
                                                     "Click Cancel to exit."), QMessageBox::Cancel);
        }



}










void MainWindow::on_buttonBox_supprimerS_accepted()
{
    Service C;
    QString Q=ui->histoservice->text();
    ui->tableView_res->setModel(C.rechercher_service(Q));
    ui->tabWidget_2->setCurrentIndex(1);

}



void MainWindow::sendMail()
{
    Smtp* smtp = new Smtp("nassim.cmmelliti@gmail.com", "jxymhvexbhvstnjc","smtp.gmail.com",587,30000);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
    smtp->sendMail("promotion", ui->lineEdit_mail->text() ,ui->textEdit->toPlainText(),ui->lineEdit_mail->text());
}

void MainWindow::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning( 0, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
}

void MainWindow::on_envoyer_clicked()
{
    connect(ui->envoyer, SIGNAL(clicked()),this, SLOT(sendMail()));
}










void MainWindow::on_lineEdit_recherche_cursorPositionChanged(int arg1, int arg2)
{
    Service C;
    if(ui->lineEdit_recherche->text()=="")
    {
        ui->tableView_res->setModel(C.afficher_serv());
    }
    else
    {
        ui->tableView_res->setModel(C.rechercher_service(ui->lineEdit_recherche->text()));
    }
}

void MainWindow::on_lineEdit_recherche_returnPressed()
{
    Service C;
    QString q=ui->lineEdit_recherche->text();
    ui->tableView_res->setModel(C.rechercher_service(q));
}

void MainWindow::on_Tri_currentTextChanged(const QString &arg1)
{
    Service C;
    if (arg1=="ID") ui->tableView_res->setModel(C.trier_serviceId());
    else if (arg1=="Nom") ui->tableView_res->setModel(C.trier_serviceNom());
    else if (arg1=="Type") ui->tableView_res->setModel(C.trier_serviceType());
}


