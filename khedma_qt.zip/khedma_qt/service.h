#ifndef SERVICE_H
#define SERVICE_H
#include <QString>
#include <QDate>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlQueryModel>
#include<qdatetimeedit.h>
#include<qdatetime.h>
#include <QVariant>
#include <QComboBox>
#include <QSqlQueryModel>

class Service
{   int idservice;
    QString nomservice,typeservice,emplacementservice,descriptionservice ;
    QDate dateservice;
    float prixservice;
public:
    Service();
    Service(int,QString,QString,QString,float,QString,QDate);


  int getid_service(){return idservice ;}
    QString getnom_service(){return nomservice;};
    QString gettype_service(){return typeservice;}
    QString getemplacement_service(){return emplacementservice;}
    float getprix_service(){return prixservice;}
    QString getdescription_service(){return descriptionservice;}
    QDate getdate_service(){return dateservice;}


    void setid_service (int c ){idservice=c;}
    void setnom_service(QString n){nomservice=n;}
    void settype_service(QString p){typeservice=p;}
    void setemplacement_service(QString m){ emplacementservice=m;}
    void setprix_service(float t){prixservice=t;}
    void setdescription_service(QString a){descriptionservice=a;}
    void setdate_service(QDate b){dateservice=b;}


    bool ajouterres();
    QSqlQueryModel * afficher_serv();
    bool modifier_serv(int idservice,QString nomservice,QString typeservice,QString emplacementservice,float prixservice,QString descriptionservice,QDate dateservice);
    bool supprimer_serv(int);
    QSqlQueryModel * chercher_serv(QString idservice);
    QSqlQueryModel * recuperer(int idservice);
    QSqlQueryModel * trier_serviceNom();
    QSqlQueryModel * trier_serviceType();
    QSqlQueryModel * trier_serviceId();
    QSqlQueryModel * rechercher_service(const QString &b);






};

#endif // SERVICE_H
